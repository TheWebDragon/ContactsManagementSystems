import { Component, OnInit, Input, inject, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms'; 
import { ContactService } from '../../api/contact.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'contact-details',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './contact-details.component.html',
  styleUrl: './contact-details.component.css'
})
export class ContactDetailsComponent { 


  //@Output("getList") getList: EventEmitter<any> = new EventEmitter<any>();
  // @Output() cancel = new EventEmitter<void>(); 
  // @Input() item: any;  

  @Input() item: any = {Id: 0, FirstName: '', LastName: '', Email: ''};

  contactForm!: FormGroup;
  constructor(private fb: FormBuilder, public activeModal: NgbActiveModal) {}
  private contactService = inject(ContactService);  
  isEdit: boolean = false;
  
  ngOnInit() {
    this.contactForm = this.fb.group({
      Id: [''],
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      Email: ['', [Validators.required, Validators.email]]      
    });

    // if (this.item) {
    //   this.contactForm.patchValue({
    //     Id: this.item.id,
    //     FirstName: this.item.firstName,
    //     LastName: this.item.lastName,
    //     Email: this.item.email
    //   });
    // }
    // else{
    //   this.contactForm.patchValue({
    //     Id: 0,
    //     FirstName: '',
    //     LastName: '',
    //     Email: ''
    //   });
    // }
  }

  // ngOnChanges(changes: SimpleChanges) {
  //   if (changes['contact'] && this.item) {
  //     this.contactForm.patchValue({
  //       Id: this.item.id,
  //       FirstName: this.item.firstName,
  //       LastName: this.item.lastName,
  //       Email: this.item.email
  //     });

  //     if(this.item.firstName != undefined){
  //       this.isEdit = true;
  //     }
  //     else{
  //       this.isEdit = false;
  //     }
  //   }
  // }

  onSubmit() {
    if (this.contactForm.valid) {
      const contactData = this.contactForm.value;
      this.contactService.CreateContactDetails(contactData).subscribe((response) => {
      alert(response.message); 
      //this.getList.emit(true);
      this.onCancel();
      this.isEdit = false;
    });
    this.activeModal.close();
    } else {
      this.contactForm.controls['FirstName'].markAsTouched();
      this.contactForm.controls['LastName'].markAsTouched();
      this.contactForm.controls['Email'].markAsTouched();
    }
  }

  onCancel() {
    // Emit cancel event to notify the parent component to show the list again
    this.activeModal.close();
    //this.cancel.emit();
  }

}


